

/**
 * Created by lzh on 3/29/16.
 */
public class DecorateObject implements Decorate {
    @Override
    public void act() {

    }
}
