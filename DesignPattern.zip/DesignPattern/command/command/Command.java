

/**
 * Created by lzh on 4/1/16.
 * 命令模式
 */
public interface Command {
    void execute();
}
