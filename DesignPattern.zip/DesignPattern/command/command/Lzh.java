

/**
 * Created by lzh on 4/1/16.
 */
public abstract class Lzh {
    public void eat(){
        System.out.println("lzh eat");
    }
    public void sleep(){
        System.out.println("lzh sleep");
    }
    public void walk(){
        System.out.println("lzh walk");
    }
}