/**
 * Created by lzh on 4/1/16.
 * 状态模式
 */
public interface State {
    void handle(String handle);
}
