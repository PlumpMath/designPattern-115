

/**
 * Created by lzh on 3/29/16.
 */
public class SearchImp implements Search {
    @Override
    public void search() {
        System.out.println("search something ");
    }
}
