

/**
 * Created by lzh on 3/29/16.
 */
public interface Computer {
    void shutdown();
}
