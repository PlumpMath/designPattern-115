

/**
 * Created by lzh on 3/29/16.
 */
public class ComputerImp implements Computer {
    @Override
    public void shutdown() {
        System.out.println("computer closed  ");
    }
}
