

/**
 * Created by lzh on 3/30/16.
 * 具体享元
 */
public interface Flyweight {
    void say(String out);
}
