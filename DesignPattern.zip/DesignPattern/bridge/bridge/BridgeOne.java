

/**
 * Created by lzh on 3/29/16.
 */
public class BridgeOne extends AbstractBridge {
    public BridgeOne(Baidu baidu) {
        super(baidu);
    }
    public void result(){
        System.out.println("lzh");
    }
}
