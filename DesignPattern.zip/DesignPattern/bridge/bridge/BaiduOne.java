

/**
 * Created by lzh on 3/29/16.
 */
public class BaiduOne implements Baidu {
    @Override
    public void search() {
        System.out.println("search one");
    }
}
