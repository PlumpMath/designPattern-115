
/**
 * Created by lzh on 3/29/16.
 */
public class BaiduTwo implements Baidu {
    @Override
    public void search() {
        System.out.println("search two");
    }
}
