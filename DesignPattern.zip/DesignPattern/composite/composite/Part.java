

/**
 * Created by lzh on 3/30/16.
 */
public class Part extends Component {
    public Part(String msg) {
        super(msg);
    }
}
