

/**
 * Created by lzh on 3/29/16.
 */
public class Real implements Person {
    @Override
    public void say() {
        System.out.println("Hello world !");
    }
}
