

/**
 * Created by lzh on 3/28/16.
 */
public class TencentImp implements Tencent {

    public String ceo() {
        return "马化腾";
    }
    public String architect() {
        return "郑全战";
    }
}
