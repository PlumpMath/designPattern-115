

/**
 * Created by lzh on 3/28/16.
 */
public interface Alibaba extends Enterprise{

}
