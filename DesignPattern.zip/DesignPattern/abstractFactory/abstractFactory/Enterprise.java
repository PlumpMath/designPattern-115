

/**
 * 企业
 */
public interface Enterprise {
    String ceo();//CEO
    String architect();//架构师
}
