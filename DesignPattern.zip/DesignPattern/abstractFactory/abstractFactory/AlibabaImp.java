

/**
 * Created by lzh on 3/28/16.
 */
public class AlibabaImp implements Alibaba{
    public String ceo() {
        return "马云";
    }

    public String architect() {
        return "王坚";
    }
}
