
/**
 * Created by lzh on 3/31/16.
 */
public abstract class Aggregate {
    public abstract Iterator createIterator();
}
