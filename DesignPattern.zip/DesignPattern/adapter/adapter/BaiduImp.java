

/**
 * Created by lzh on 3/30/16.
 */
public class BaiduImp extends Alibaba implements Baidu {
    @Override
    public void liyanhong() {
        super.mayun();
        System.out.println("Baidu");
    }
}
