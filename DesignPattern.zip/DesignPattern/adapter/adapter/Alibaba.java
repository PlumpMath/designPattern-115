

/**
 * Created by lzh on 3/30/16.
 */
public class Alibaba {
    public void mayun(){
        System.out.println("Alibaba");
    }
}
