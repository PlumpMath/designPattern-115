

/**
 * Created by lzh on 3/30/16.
 */
public class LZH_2 extends AbstractFather {
    @Override
    public void eat() {
        super.eat();
        System.out.println("lzh eat food ");
    }
}
