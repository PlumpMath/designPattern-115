
/**
 * Created by lzh on 3/30/16.
 * 模板方法模式
 */
public class AbstractFather {
    public void say(){}
    public void walk(){}
    public void eat(){}
    public void sleep(){}
}
