
/**
 * Created by lzh on 3/30/16.
 */
public class LZH_1 extends AbstractFather {
    @Override
    public void sleep() {
        super.sleep();
        System.out.println("lzh sleep");
    }
}
