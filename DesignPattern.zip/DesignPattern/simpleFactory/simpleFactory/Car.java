

/**
 * Created by lzh on 3/28/16.
 */
public interface Car {
    String name();
    String color();
    int pay();
}
