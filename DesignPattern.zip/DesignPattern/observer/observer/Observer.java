

/**
 * Created by lzh on 3/31/16.
 */
public interface Observer {
    void update(String msg);
}
