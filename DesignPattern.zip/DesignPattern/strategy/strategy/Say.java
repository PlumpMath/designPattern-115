
/**
 * Created by lzh on 3/30/16.
 */
public class Say implements Strategy {
    @Override
    public void doSomething() {
        System.out.println("令照辉真帅");
    }
}
