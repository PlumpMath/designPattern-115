

/**
 * Created by lzh on 3/30/16.
 */
public class Eat implements Strategy {
    @Override
    public void doSomething() {
        System.out.println("i like eat tiger..");
    }
}
