

/**
 * Created by lzh on 3/30/16.
 */
public class Walk implements Strategy {
    @Override
    public void doSomething() {
        System.out.println("i walk to Baijing");
    }
}
