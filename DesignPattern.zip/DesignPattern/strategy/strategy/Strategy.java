

/**
 * Created by lzh on 3/30/16.
 */
public interface Strategy {
    void doSomething();
}
